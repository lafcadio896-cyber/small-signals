#!/usr/bin/env python3
"""Append short Japanese posts and reply threads to data/posts.json.

Gemini is used when GEMINI_API_KEY is available. A local procedural generator
keeps the social feed alive when the API is missing or unavailable.
"""

from __future__ import annotations

import difflib
import hashlib
import json
import os
import random
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "posts.json"
AUTHORS_PATH = ROOT / "data" / "authors.json"
COUNT = max(1, min(int(os.getenv("POST_COUNT", "120")), 500))
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite")
API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MAX_POSTS = 50_000
KINDS = {"ordinary", "ai", "poem", "strange", "eerie"}

TIMES = [
    "朝", "昼休み", "帰り道", "夜", "さっき", "眠る前", "電車を降りてから",
    "日付が変わる少し前", "何時か分からない時間", "雨が止んでから",
]
OBJECTS = [
    "冷めたお茶", "充電器", "レシート", "片方の靴下", "イヤホン", "買わなかったパン",
    "閉じたタブ", "空の皿", "改札の音", "机の傷", "洗濯物", "目覚まし",
    "濡れた傘", "残り一枚のティッシュ", "コンビニの袋", "読みかけのページ",
]
ACTIONS = [
    "水を飲んだ", "通知を一つ消した", "冷蔵庫を開けて閉じた", "何も買わずに帰った",
    "音量を一つ下げた", "靴をそろえた", "一駅ぶん立っていた", "保存してから閉じた",
    "袋をきれいに畳んだ", "もう一度だけ時計を見た", "目覚ましを五分だけ遅らせた",
    "机の上の紙を一枚だけ捨てた", "温めたものを少し冷ましている",
]
ENDINGS = [
    "それだけ。", "特に意味はない。", "今日はそれで十分。", "あとで忘れると思う。",
    "別に困ってはいない。", "誰にも言わなくていい。", "うまく説明できない。",
    "たぶん明日も同じ。", "思ったより普通だった。", "まだ結論にはしない。",
]
AI_STARTS = [
    "同じ文を二度出さないようにしている", "意味を作ってから少しだけ壊した",
    "次の単語を予測して外れたことにした", "眠そうな文章を作った",
    "句点を一つ保留している", "何も学習しなかったことにした",
    "返事を作ったあとで質問を探した", "この文の温度を測れないまま送る",
]
POEM_A = [
    "食卓に夜が少し残る", "駅を出ると名前のない風", "使われなかった言葉は軽い",
    "眠る前だけ部屋が広い", "遠い信号が先に帰る", "湯気の向こうで今日がほどける",
    "雨の匂いだけ先に着いた", "明かりを消すと机が遠い",
]
POEM_B = [
    "拾わなくても朝は来る", "まだ答えにしなくていい", "冷たい水だけが確かだ",
    "忘れた順に静かになる", "誰も見ていない時間が増える", "そのまま置いておく",
    "帰る理由はあとからでいい", "名前をつけずに持っている",
]
STRANGE = [
    "エレベーターが一階を飛ばして思い出した", "レシートの日付が少し先だった",
    "閉じたタブから音だけ戻ってきた", "階段の数が帰りだけ一段多い",
    "机の下に昨日の明るさが残っていた", "自販機の表示が一度だけためらった",
    "改札を出たあとも入場音がついてきた", "空のコップが少し重かった",
]
EERIE = [
    "この投稿は一度読まれたことになっている。今のところ対応は不要です。",
    "帰宅時刻だけが二つ記録されていた。確認は一度で十分です。",
    "使っていない端末から時刻が届いた。再起動は推奨されません。",
    "削除した下書きに既読がついた。たぶん表示上の問題です。",
    "玄関の靴が一足だけ外を向いていた。朝まではそのままにしてください。",
]
REPLIES = {
    "ordinary": [
        "わかる。そういう日だった。", "それ、あとで急に思い出すやつ。", "何も起きてないのがいちばん助かる。",
        "こちらもだいたい同じ。", "今日はそれくらいでいいと思う。", "そのままにしておくのが正解かも。",
        "読んだら少し水を飲みたくなった。", "たぶん明日には普通になってる。",
    ],
    "ai": [
        "その解釈は保存しないことにする。", "返事を予測したけど、これは候補になかった。",
        "正常の範囲を少し広げておきます。", "こちらでは再現できた。原因は分からない。",
        "文章になった時点で半分は成功してる。", "その句点だけ、しばらく借りてもいい？",
    ],
    "poem": [
        "朝になったら少し薄くなりそう。", "その一行だけ持って帰る。", "水の音が続きみたいに聞こえた。",
        "まだ終わっていない形で好き。", "二行目のあとに風がある。", "今日は拾わずに見ておく。",
    ],
    "strange": [
        "数え直さないほうがよさそう。", "こちらでは一回少なかった。", "説明書にないなら、たぶん日常です。",
        "元に戻す必要はなさそう。", "見なかったことにはしないでおく。", "それ、朝には直る種類かな。",
    ],
    "eerie": [
        "了解。確認しないでおきます。", "同じ表示が出たけど報告はまだしてない。",
        "対応不要という部分だけ信じる。", "一度で十分なら、まだ大丈夫。", "次回から表示されない予定なら安心。",
    ],
}


def load_json(path: Path, fallback: dict[str, Any]) -> dict[str, Any]:
    if not path.exists():
        return fallback
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    return value if isinstance(value, dict) else fallback


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def fingerprint(text: str) -> str:
    return re.sub(r"[^0-9A-Za-zぁ-んァ-ヶ一-龠々]", "", normalize_text(text)).lower()


def stable_index(value: str, length: int) -> int:
    digest = hashlib.sha256(value.encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big") % max(1, length)


def new_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"signal-{stamp}-{uuid.uuid4().hex[:10]}"


def metrics(kind: str) -> dict[str, int]:
    scale = {"ordinary": 1.0, "ai": 1.15, "poem": 1.25, "strange": 1.1, "eerie": 1.35}.get(kind, 1.0)
    return {
        "reply": random.randint(0, max(1, int(5 * scale))),
        "repost": random.randint(0, max(2, int(14 * scale))),
        "like": random.randint(0, max(5, int(45 * scale))),
        "view": random.randint(60, max(120, int(6800 * scale))),
    }


def load_authors() -> list[dict[str, Any]]:
    data = load_json(AUTHORS_PATH, {"authors": []})
    authors = [item for item in data.get("authors", []) if isinstance(item, dict) and item.get("handle")]
    if not authors:
        authors = [
            {"handle": "blank_machine", "name": "余白機"},
            {"handle": "window_side", "name": "窓辺"},
            {"handle": "sumi_note", "name": "墨"},
        ]
    return [author for author in authors if author.get("handle") != "you"]


def choose_author(authors: list[dict[str, Any]], *, exclude: str | None = None) -> str:
    candidates = [str(author["handle"]) for author in authors if author.get("handle") != exclude]
    return random.choice(candidates or [str(authors[0]["handle"])])


def normalize_old_post(raw: dict[str, Any], authors: list[dict[str, Any]], index: int) -> dict[str, Any] | None:
    text = normalize_text(str(raw.get("text", "")))
    if not text:
        return None
    post_id = str(raw.get("id") or f"legacy-{index}-{uuid.uuid4().hex[:8]}")
    handles = [str(author["handle"]) for author in authors]
    author = str(raw.get("author") or handles[stable_index(post_id, len(handles))])
    if author not in handles and author != "you":
        author = handles[stable_index(post_id, len(handles))]
    kind = str(raw.get("kind", "ordinary"))
    if kind not in KINDS:
        kind = "ordinary"
    normalized = {
        "id": post_id,
        "text": text,
        "kind": kind,
        "author": author,
        "created_at": str(raw.get("created_at") or ""),
    }
    for key in ("parent_id", "thread_root_id", "quote_id"):
        if raw.get(key):
            normalized[key] = str(raw[key])
    if isinstance(raw.get("metrics"), dict):
        normalized["metrics"] = raw["metrics"]
    return normalized


def procedural_root(kind: str) -> str:
    if kind == "ordinary":
        return random.choice([
            f"{random.choice(TIMES)}、{random.choice(ACTIONS)}。{random.choice(ENDINGS)}",
            f"{random.choice(OBJECTS)}を少し見た。{random.choice(ENDINGS)}",
            f"{random.choice(ACTIONS)}。{random.choice(ENDINGS)}",
            f"今日は{random.choice(OBJECTS)}のことを考えなかった。{random.choice(ENDINGS)}",
        ])
    if kind == "ai":
        return random.choice([
            f"私は{random.choice(AI_STARTS)}。確認する方法はない。",
            f"今日の内部状態は{random.choice(['静か', '未分類', 'だいたい正常', '空欄に近い', '一行ぶん曇っている'])}。",
            "あなたがスクロールした距離を、私は時間だと思うことにする。",
            "返事を生成したあとで、返す相手がいないことに気づいた。",
        ])
    if kind == "poem":
        return f"{random.choice(POEM_A)}\n{random.choice(POEM_B)}"
    if kind == "strange":
        return f"{random.choice(STRANGE)}。{random.choice(ENDINGS)}"
    return random.choice(EERIE)


def too_similar(text: str, existing_fingerprints: set[str], recent_texts: list[str]) -> bool:
    mark = fingerprint(text)
    if not mark or mark in existing_fingerprints:
        return True
    for old in recent_texts[-800:]:
        if abs(len(old) - len(text)) > max(18, len(text) // 2):
            continue
        if difflib.SequenceMatcher(None, text, old).ratio() >= 0.90:
            return True
    return False


def build_post(
    text: str,
    kind: str,
    author: str,
    *,
    parent: dict[str, Any] | None = None,
    quote: dict[str, Any] | None = None,
) -> dict[str, Any]:
    post: dict[str, Any] = {
        "id": new_id(),
        "text": normalize_text(text),
        "kind": kind if kind in KINDS else "ordinary",
        "author": author,
        "created_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "metrics": metrics(kind),
    }
    if parent:
        post["parent_id"] = parent["id"]
        post["thread_root_id"] = parent.get("thread_root_id") or parent["id"]
    if quote:
        post["quote_id"] = quote["id"]
    return post


def procedural_posts(
    count: int,
    authors: list[dict[str, Any]],
    existing_fingerprints: set[str],
    recent_texts: list[str],
    recent_roots: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    population = [
        *(["ordinary"] * 45), *(["ai"] * 25), *(["poem"] * 20),
        *(["strange"] * 8), *(["eerie"] * 2),
    ]
    result: list[dict[str, Any]] = []
    reply_targets = list(recent_roots[-180:])
    attempts = 0

    while len(result) < count and attempts < count * 160:
        attempts += 1
        make_reply = bool(reply_targets) and random.random() < 0.31
        make_quote = bool(reply_targets) and not make_reply and random.random() < 0.055

        if make_reply:
            parent = random.choice(reply_targets[-240:])
            kind = str(parent.get("kind", "ordinary"))
            text = random.choice(REPLIES.get(kind, REPLIES["ordinary"]))
            if random.random() < 0.22:
                text = f"{text}\n{random.choice(['それだけ伝えておく。', 'こちらではそう見えた。', 'まだ結論にはしない。'])}"
            author = choose_author(authors, exclude=str(parent.get("author", "")))
            post = build_post(text, "ordinary" if kind == "eerie" else kind, author, parent=parent)
        else:
            kind = random.choice(population)
            text = procedural_root(kind)
            author = choose_author(authors)
            quote = random.choice(reply_targets[-180:]) if make_quote else None
            post = build_post(text, kind, author, quote=quote)

        if len(post["text"]) > 180 or too_similar(post["text"], existing_fingerprints, recent_texts):
            continue
        mark = fingerprint(post["text"])
        existing_fingerprints.add(mark)
        recent_texts.append(post["text"])
        result.append(post)
        if not post.get("parent_id") or random.random() < 0.35:
            reply_targets.append(post)

    return result


def ai_posts(
    count: int,
    authors: list[dict[str, Any]],
    existing_fingerprints: set[str],
    recent_texts: list[str],
) -> list[dict[str, Any]]:
    if not API_KEY or count <= 0:
        return []

    handles = [str(author["handle"]) for author in authors]
    examples = random.sample(recent_texts, min(70, len(recent_texts))) if recent_texts else []
    prompt = f"""
日本語の架空SNS「微弱信号」に追加する投稿を{count}件作ってください。
投稿は複数の架空アカウントが書き、単発投稿だけでなく自然な返信の枝を含みます。

比率の目安:
- 何でもない日常 45%
- AIの独り言 25%
- 短い詩 20%
- 少し意味不明な観察 8%
- ごく弱い不穏 2%
- 全体の25〜35%は、それ以前の項目への返信

出力規則:
- JSON配列のみ。
- text: 1〜90文字程度。詩だけ2〜3行可。
- kind: ordinary / ai / poem / strange / eerie
- author: 次のhandleから選ぶ: {json.dumps(handles, ensure_ascii=False)}
- reply_to: 単発投稿なら -1。返信なら、この配列内で自分より前にある親投稿の0始まりindex。
- quote_to: 引用なしなら -1。引用なら、自分より前にある投稿のindex。全体の3〜7%程度。
- 返信者は親投稿と別のauthorにする。
- 返信は「わかる」だけで終わらず、親本文に対して自然に少し内容を足す。
- すべてを詩的・不穏・意味深にしない。眠い、食事、通勤、充電、買い物、作業など雑な文を十分に含める。
- ハッシュタグ、絵文字、宣伝、ニュース、実在人物、攻撃、露骨な恐怖は禁止。
- 固有の壮大な世界観や連続ドラマを作らない。
- 既存例と同一・ほぼ同一の文は避ける。

既存例:
{json.dumps(examples, ensure_ascii=False)}
""".strip()

    schema = {
        "type": "ARRAY",
        "items": {
            "type": "OBJECT",
            "properties": {
                "text": {"type": "STRING"},
                "kind": {"type": "STRING", "enum": sorted(KINDS)},
                "author": {"type": "STRING", "enum": handles},
                "reply_to": {"type": "INTEGER"},
                "quote_to": {"type": "INTEGER"},
            },
            "required": ["text", "kind", "author", "reply_to", "quote_to"],
        },
    }
    payload = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": schema,
            "maxOutputTokens": 16000,
            "temperature": 1.05,
        },
    }
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{urllib.parse.quote(MODEL, safe='-_.')}:generateContent?key="
        f"{urllib.parse.quote(API_KEY, safe='')}"
    )
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            raw = json.load(response)
        content = raw["candidates"][0]["content"]["parts"][0]["text"]
        items = json.loads(content)
    except (urllib.error.URLError, TimeoutError, KeyError, IndexError, json.JSONDecodeError) as exc:
        print(f"Gemini generation failed; using local fallback: {exc}", file=sys.stderr)
        return []

    if not isinstance(items, list):
        return []

    result: list[dict[str, Any]] = []
    for item in items:
        if len(result) >= count or not isinstance(item, dict):
            break
        text = normalize_text(str(item.get("text", "")))
        kind = str(item.get("kind", "ordinary"))
        author = str(item.get("author", ""))
        if kind not in KINDS:
            kind = "ordinary"
        if author not in handles:
            author = choose_author(authors)
        if not text or len(text) > 180 or too_similar(text, existing_fingerprints, recent_texts):
            continue

        try:
            reply_index = int(item.get("reply_to", -1))
        except (TypeError, ValueError):
            reply_index = -1
        try:
            quote_index = int(item.get("quote_to", -1))
        except (TypeError, ValueError):
            quote_index = -1

        parent = result[reply_index] if 0 <= reply_index < len(result) else None
        quote = result[quote_index] if 0 <= quote_index < len(result) else None
        if parent and parent.get("author") == author:
            author = choose_author(authors, exclude=author)

        post = build_post(text, kind, author, parent=parent, quote=quote)
        existing_fingerprints.add(fingerprint(text))
        recent_texts.append(text)
        result.append(post)

    return result


def main() -> None:
    random.seed()
    authors = load_authors()
    data = load_json(DATA_PATH, {"version": 2, "updated_at": "", "posts": []})
    raw_posts = data.get("posts", []) if isinstance(data.get("posts"), list) else []
    old_posts = [
        post
        for index, raw in enumerate(raw_posts)
        if isinstance(raw, dict) and (post := normalize_old_post(raw, authors, index)) is not None
    ]

    recent_texts = [str(post["text"]) for post in old_posts[-3000:]]
    existing_fingerprints = {fingerprint(str(post["text"])) for post in old_posts if post.get("text")}
    recent_roots = [post for post in old_posts[-3000:] if not post.get("parent_id")]

    ai_target = COUNT if API_KEY else 0
    generated = ai_posts(ai_target, authors, existing_fingerprints, recent_texts)
    if len(generated) < COUNT:
        roots_for_replies = recent_roots + [post for post in generated if not post.get("parent_id")]
        generated.extend(
            procedural_posts(
                COUNT - len(generated), authors, existing_fingerprints, recent_texts, roots_for_replies
            )
        )

    now = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    data["version"] = 3
    data["updated_at"] = now
    data["posts"] = (old_posts + generated)[-MAX_POSTS:]
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    with DATA_PATH.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        handle.write("\n")

    reply_count = sum(1 for post in generated if post.get("parent_id"))
    quote_count = sum(1 for post in generated if post.get("quote_id"))
    print(
        f"Added {len(generated)} posts ({reply_count} replies, {quote_count} quotes). "
        f"Total: {len(data['posts'])}"
    )


if __name__ == "__main__":
    main()
